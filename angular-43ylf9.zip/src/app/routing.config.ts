import { UIRouter, UrlParts } from "@uirouter/angular";

export function routerConfig(uiRouter: UIRouter) {
  // // Show the ui-router visualizer
  // let vis = window["ui-router-visualizer"];
  // vis.visualizer(uiRouter);
  const transitionService = uiRouter.transitionService;
}
