import { Component, OnInit } from "@angular/core";

@Component({
  selector: "app-admin-user-list",
  template: `
    <p>
      admin-user-list works!
    </p>
  `,
  styles: []
})
export class AdminUserListComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
