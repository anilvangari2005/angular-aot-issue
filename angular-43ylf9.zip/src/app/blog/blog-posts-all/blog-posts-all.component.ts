import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-blog-posts-all',
  template: `
    <p>
      blog-posts-all works!
    </p>
  `,
  styles: []
})
export class BlogPostsAllComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
