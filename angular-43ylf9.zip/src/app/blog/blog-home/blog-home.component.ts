import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-blog-home',
  template: `
    <p>
      blog-home works!
    </p>
  `,
  styles: []
})
export class BlogHomeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
